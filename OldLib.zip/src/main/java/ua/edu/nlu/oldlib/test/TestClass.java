package ua.edu.nlu.oldlib.test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pc8 on 10.03.16.
 */
public class TestClass {

    public String message = "ss";

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public static void main(String[] args) throws IOException, NoSuchFieldException, IllegalAccessException {
//        ApplicationContext context = new ClassPathXmlApplicationContext("spring-context.xml");
//        DefaultFtpSessionFactory defaultFtpSessionFactory = (DefaultFtpSessionFactory)  context.getBean("ftpClientFactory");
//
//      for (int i = 1; i < 100; i++) {
//          defaultFtpSessionFactory.getSession().read("10/1006/" + i + ".jpg", new FileOutputStream(new File("/home/pc8/TEST/"+i+".jpg")));
//      }
//        System.out.println(Arrays.toString(defaultFtpSessionFactory.getSession().listNames("10")));
       List<String> list = new ArrayList<>();
        list.add("first");
        list.add("second");
        list.remove(1);
        list.add(1,"third");
        System.out.println(list.get(4));





    }

}
